import { useMemo, useState } from 'react';
import { ArrowUpRight, Bike, CarFront, Gauge, Search, SlidersHorizontal, Zap } from 'lucide-react';

const vehicles = [
  { id: 1, name: 'Apex R1', type: 'Bike', category: 'Sport', price: '₹2.15 Lakh', speed: '299 km/h', power: '200 HP', tag: 'TRACK READY', art: 'bike-red', description: 'Precision engineering for every curve.' },
  { id: 2, name: 'Trail X', type: 'Bike', category: 'Adventure', price: '₹1.85 Lakh', speed: '180 km/h', power: '48 HP', tag: 'GO FURTHER', art: 'bike-orange', description: 'Built for the road less travelled.' },
  { id: 3, name: 'Phantom GT', type: 'Car', category: 'Sports', price: '₹78 Lakh', speed: '320 km/h', power: '520 HP', tag: 'PURE PERFORMANCE', art: 'car-blue', description: 'A bold silhouette with thrilling performance.' },
  { id: 4, name: 'Metro E', type: 'Car', category: 'Electric', price: '₹24 Lakh', speed: '200 km/h', power: '310 HP', tag: 'ELECTRIC DRIVE', art: 'car-violet', description: 'Quiet confidence, instant acceleration.' },
  { id: 5, name: 'Classic 650', type: 'Bike', category: 'Cruiser', price: '₹3.40 Lakh', speed: '165 km/h', power: '52 HP', tag: 'TIMELESS STYLE', art: 'bike-dark', description: 'A relaxed ride with unmistakable character.' },
  { id: 6, name: 'Summit SUV', type: 'Car', category: 'SUV', price: '₹36 Lakh', speed: '220 km/h', power: '280 HP', tag: 'READY FOR ANYTHING', art: 'car-green', description: 'Space, strength and comfort in one package.' },
];

function VehicleArt({ vehicle }) {
  return (
    <div className={`vehicle-art ${vehicle.art}`} aria-label={`${vehicle.type} illustration`}>
      <div className="art-glow" />
      <div className="vehicle-emoji" aria-hidden="true">{vehicle.type === 'Bike' ? '🏍️' : '🏎️'}</div>
      <span className="art-label">{vehicle.type === 'Bike' ? 'TWO WHEELS' : 'FOUR WHEELS'}</span>
    </div>
  );
}

function App() {
  const [filter, setFilter] = useState('All');
  const [search, setSearch] = useState('');
  const [saved, setSaved] = useState([]);

  const filtered = useMemo(() => vehicles.filter(v => {
    const matchesType = filter === 'All' || v.type === filter;
    const matchesSearch = `${v.name} ${v.category} ${v.type}`.toLowerCase().includes(search.toLowerCase());
    return matchesType && matchesSearch;
  }), [filter, search]);

  const toggleSaved = id => setSaved(current => current.includes(id) ? current.filter(x => x !== id) : [...current, id]);

  return (
    <main>
      <nav className="nav wrap">
        <a className="brand" href="#"><span className="brand-mark"><Zap size={17} fill="currentColor" /></span> VELOCITY<span className="brand-dot">.</span></a>
        <div className="nav-links"><a href="#collection">Collection</a><a href="#about">About</a><a href="#contact">Contact</a></div>
        <a className="nav-cta" href="#collection">Explore <ArrowUpRight size={16} /></a>
      </nav>

      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span /> THE ART OF THE DRIVE</div>
          <h1>Find your<br /><em>next</em> adventure.</h1>
          <p>From agile two-wheelers to powerful machines. Discover the rides that move you.</p>
          <div className="hero-actions">
            <a className="primary-btn" href="#collection">Explore collection <ArrowUpRight size={17} /></a>
            <a className="text-btn" href="#about">Discover our story</a>
          </div>
          <div className="hero-stats">
            <div><strong>06</strong><span>FEATURED RIDES</span></div>
            <div><strong>02</strong><span>WAYS TO EXPLORE</span></div>
            <div><strong>∞</strong><span>PLACES TO GO</span></div>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-orbit orbit-one" /><div className="hero-orbit orbit-two" />
          <div className="hero-vehicle">🏎️</div>
          <div className="floating-card"><span className="live-dot" /> FEATURED MACHINE <b>PHANTOM GT</b><small>Performance, reimagined.</small></div>
          <div className="vertical-note">DESIGNED TO MOVE YOU · 2026</div>
        </div>
      </section>

      <section className="collection wrap" id="collection">
        <div className="section-top">
          <div><div className="eyebrow">THE LINEUP</div><h2>Choose your <em>ride.</em></h2></div>
          <p>Every journey starts somewhere.<br />Make yours unforgettable.</p>
        </div>
        <div className="toolbar">
          <div className="filters">
            {['All', 'Bike', 'Car'].map(item => <button key={item} className={filter === item ? 'filter active' : 'filter'} onClick={() => setFilter(item)}>
              {item === 'Bike' && <Bike size={15} />}{item === 'Car' && <CarFront size={15} />}{item === 'All' && <SlidersHorizontal size={15} />}{item === 'All' ? 'All rides' : `${item}s`}
            </button>)}
          </div>
          <label className="search"><Search size={16} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search the collection..." /></label>
        </div>
        <div className="vehicle-grid">
          {filtered.map(v => <article className="vehicle-card" key={v.id}>
            <div className="card-image"><VehicleArt vehicle={v} /><span className="tag">{v.tag}</span><button className={`save ${saved.includes(v.id) ? 'saved' : ''}`} onClick={() => toggleSaved(v.id)} aria-label="Save vehicle">{saved.includes(v.id) ? '♥' : '♡'}</button></div>
            <div className="card-body">
              <div className="card-kicker">{v.type} <span>·</span> {v.category}</div>
              <div className="card-title-row"><h3>{v.name}</h3><strong>{v.price}</strong></div>
              <p>{v.description}</p>
              <div className="specs"><span><Gauge size={14} /> {v.speed}</span><span><Zap size={14} /> {v.power}</span></div>
            </div>
          </article>)}
        </div>
        {filtered.length === 0 && <div className="empty">No rides found. Try another search.</div>}
      </section>

      <section className="about wrap" id="about">
        <div className="about-art"><div className="about-ring" /><span>⚡</span><small>BUILT FOR<br />THE JOURNEY</small></div>
        <div className="about-copy"><div className="eyebrow">MORE THAN A MACHINE</div><h2>It's not just<br />the destination.<br /><em>It's the feeling.</em></h2><p>Velocity is a celebration of design, engineering and the freedom of the open road. Find inspiration for your next ride.</p><a className="text-btn" href="#collection">Find your ride <ArrowUpRight size={16} /></a></div>
      </section>

      <footer id="contact"><div className="wrap footer-inner"><a className="brand" href="#"><span className="brand-mark"><Zap size={17} fill="currentColor" /></span> VELOCITY<span className="brand-dot">.</span></a><span>Made for the love of the ride.</span><span>© 2026 VELOCITY</span></div></footer>
    </main>
  );
}

export default App;